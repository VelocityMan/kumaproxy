#!/bin/bash
echo "Starting KumaCraft Proxy..."
exec java -jar velocity.jar
